import Banner from './components/Banner/Banner';
import ListaCards from './components/ListaCards/ListaCards';
import './App.module.css';
import Header from "./components/Header/Header.jsx";
import Controles from "./components/Controles/Controles.jsx";
import Rodape from "./components/Rodape/Rodape.jsx";

export default function App() {
    const seriesEmAlta = [
        {
            id: 1,
            titulo: "Breaking Bad",
            imagem: "/brbad.jpg"
        },
        {
            id: 2,
            titulo: "Cobra Kai",
            imagem: "/cobrakai.jpg"
        },
        {
            id: 3,
            titulo: "Stranger Things",
            imagem: "/std.jpg"
        },
        {
            id: 4,
            titulo: "The Walking Dead",
            imagem: "/twdd.jpg"
        },
        {
            id: 5,
            titulo: "Dexter",
            imagem: "/dex.jpg"
        },
        {
            id: 6,
            titulo: "Rick and Morty",
            imagem: "/ric.jpg"
        }
    ];

    return (
        <div>
            <Header />
            {/* O Banner no topo */}
            <Banner />

            <Controles />

            {/* A fileira recebendo a sua lista de séries */}
            <ListaCards titulo="Séries em Alta" itens={seriesEmAlta} />

            <Rodape />
        </div>
    );
}
