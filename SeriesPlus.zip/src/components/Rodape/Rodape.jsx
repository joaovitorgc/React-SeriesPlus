import css from './Rodape.module.css';

export default function Rodape() {
    return (
        <footer className={css.rodape}>
            <div className={css.container}>
                <p className={css.duvidas}>Dúvidas? Ligue 0800 123 4567</p>

                <div className={css.links}>
                    <a href="#faq">Perguntas Frequentes</a>
                    <a href="#centro">Centro de Ajuda</a>
                    <a href="#termos">Termos de Uso</a>
                    <a href="#privacidade">Privacidade</a>
                    <a href="#cookies">Preferências de Cookies</a>
                    <a href="#corporativo">Informações Corporativas</a>
                </div>

                <p className={css.copyright}>
                    &copy; {new Date().getFullYear()} SeriesPlus. Todos os direitos reservados.
                </p>
            </div>
        </footer>
    );
}