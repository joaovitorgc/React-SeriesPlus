import css from "./Header.module.css"

export default function Header({ titulo = "SERIESPLUS" }) {
    return (
        <header className={css.fundoHeader}>
            <div className="container">
                <div className="row">
                    <div className="col-md-12 d-flex align-items-center justify-content-between">

                        <h1 className={css.titulo}>{titulo}</h1>

                        <nav className={css.nav}>

                            <a href="#">Catálogo</a>
                            <a href="#">Lançamentos</a>
                            <a href="#">Mais Vistos</a>

                            <a href="#" className={css.botaoLogin}>
                                Login Admin
                            </a>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    )
}