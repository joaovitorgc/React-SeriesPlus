import { useState } from "react";
import css from "./Header.module.css";

export default function Header({ titulo = "SERIESPLUS" }) {
    const [menuAberto, setMenuAberto] = useState(false);

    const toggleMenu = () => {
        setMenuAberto(!menuAberto);
    };

    return (
        <header className={css.fundoHeader}>
            <div className="container">
                <div className="row">
                    <div className="col-md-12 d-flex align-items-center justify-content-between">

                        <h1 className={css.titulo}>{titulo}</h1>

                        <button className={css.botaoMenu} onClick={toggleMenu} aria-label="Abrir menu">
                            ☰
                        </button>

                        <nav className={`${css.nav} ${menuAberto ? css.navAberta : ""}`}>
                            <a href="#">Catálogo</a>
                            <a href="#">Lançamentos</a>
                            <a href="#">Mais Vistos</a>

                            <a href="#" className={css.botaoLogin}>
                                Login Admin
                            </a>
                        </nav>

                    </div>
                </div>
            </div>
        </header>
    );
}