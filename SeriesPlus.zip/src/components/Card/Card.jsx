import css from './Card.module.css';

export default function Card({ imagem, titulo }) {
    return (
        <div className={css.card}>
            <img
                src={imagem}
                alt={`Pôster da série ${titulo}`}
                className={css.imagem}
            />

            {/* Essa div cria um degradê escuro por cima da imagem e guarda o título */}
            <div className={css.overlay}>
                <h3 className={css.titulo}>{titulo}</h3>
            </div>
        </div>
    );
}