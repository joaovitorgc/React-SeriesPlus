import css from './Controles.module.css';

export default function Controles() {
    return (
        <section className={css.container}>
            {/* Lado Esquerdo: Campo de Busca */}
            <div className={css.busca}>


                <img
                    src="/lupa.png"
                    alt="Ícone de Lupa"
                    className={css.icone}
                />

                <input
                    type="text"
                    placeholder="Buscar séries e filmes..."
                    className={css.inputBusca}
                />
            </div>

            {/* Lado Direito: Ordenação */}
            <div className={css.ordenacao}>
                <label htmlFor="ordenar" className={css.label}>Ordenar por:</label>
                <select id="ordenar" className={css.selectOrdenacao}>
                    <option value="relevancia">Relevância</option>
                    <option value="az">A - Z</option>
                    <option value="za">Z - A</option>
                    <option value="lancamento">Ano de Lançamento</option>
                </select>
            </div>
        </section>
    );
}