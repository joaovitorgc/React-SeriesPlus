import css from './Botao.module.css';

export default function Botao({ texto, estilo }) {

    const classeEstilo = estilo === 'claro' ? css.claro : css.padrao;

    return (
        <button className={`${css.botao} ${classeEstilo}`}>
            {texto}
        </button>
    );
}