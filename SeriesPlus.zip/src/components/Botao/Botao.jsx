import css from "./Botao.module.css"

export default function Botao({texto, estilo = "botao"}){

    return(
        <button className={css[estilo]}>
            <a href="/">
                {texto}
            </a>
        </button>

    )
}