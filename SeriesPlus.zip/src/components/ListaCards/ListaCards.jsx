import css from './ListaCards.module.css';
import Card from '../Card/Card.jsx';

export default function ListaCards({ titulo, itens }) {
    return (
        <section className={css.container}>

            <h2 className={css.tituloLista}>{titulo}</h2>


            <div className={css.fileira}>
                {itens.map((item) => (

                    <div key={item.id} className={css.itemWrap}>
                        <Card imagem={item.imagem} titulo={item.titulo} />
                    </div>
                ))}
            </div>
        </section>
    );
}