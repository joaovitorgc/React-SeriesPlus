import css from "./Banner.module.css"
import Botao from "../Botao/Botao.jsx";

export default function Banner() {

    return (
        <section className={css.banner}>
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className={css.conteudo}>
                            <span className={css.tag}>STREAMING EXCLUSIVO</span>
                            <h2 className={css.titulo}>
                                Descubra seu <br /> próximo capítulo
                            </h2>
                            <p className={css.texto}>
                                Mergulhe em histórias que transformam. Explore nossa seleção
                                premium de obras clássicas e contemporâneas.
                            </p>
                        </div>

                        <Botao texto={"Botao 1"} />
                        <Botao texto={"Botao 2"} estilo={"claro"} />
                    </div>
                </div>
            </div>
        </section>
    )
}