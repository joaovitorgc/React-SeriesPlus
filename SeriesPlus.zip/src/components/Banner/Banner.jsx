import { useState, useEffect } from "react";
import css from "./Banner.module.css";
import Botao from "../Botao/Botao.jsx";


const series = [
    {
        id: 1,
        imagem: "/brba.jpg",
        tag: "STREAMING EXCLUSIVO",
        titulo: <>Descubra seu <br /> próximo capítulo</>,
        texto: "Mergulhe em histórias que transformam. Explore nossa seleção premium de obras clássicas e contemporâneas.",
        corGradiente: "rgba(177, 176, 21, 0.9)"
    },
    {
        id: 2,
        imagem: "/twd.webp",
        tag: "APOCALIPSE",
        titulo: <>O Fim <br /> Chegou</>,
        texto: "Acompanhe a batalha implacável pela Sobrevivêncua. Ação, guerra e zumbis te aguardam.",
        corGradiente: "rgba(27,88,67,0.9)"
    },
    {
        id: 3,
        imagem: "/st.jpg",
        tag: "FICÇÃO CIENTÍFICA",
        titulo: <>Mundo <br /> Invertido</>,
        texto: "Mergulhe nos mistérios de Hawkins e enfrente os perigos que espreitam no escuro.",
        corGradiente: "rgba(183, 28, 28, 0.9)"
    }
];

export default function Banner() {
    const [indiceAtual, setIndiceAtual] = useState(0);


    useEffect(() => {
        const intervalo = setInterval(() => {
            setIndiceAtual((indiceAnterior) =>
                indiceAnterior === series.length - 1 ? 0 : indiceAnterior + 1
            );
        }, 4000); // 4000 milissegundos = 4 segundos

        return () => clearInterval(intervalo); // Limpa o intervalo se o componente for desmontado
    }, []);

    const slide = series[indiceAtual];

    return (
        <section
            className={css.banner}
            //Imagem e o gradiente dinamicamente via style inline
            style={{
                backgroundImage: `linear-gradient(to right, ${slide.corGradiente} 10%, rgba(0, 0, 0, 0) 40%), url('${slide.imagem}')`
            }}
        >
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className={css.conteudo}>
                            <span className={css.tag}>{slide.tag}</span>
                            <h2 className={css.titulo}>
                                {slide.titulo}
                            </h2>
                            <p className={css.texto}>
                                {slide.texto}
                            </p>
                        </div>

                        <Botao texto={"Explorar Catálogo"} />
                        <Botao texto={"Ver promoções"} estilo={"claro"} />
                    </div>
                </div>
            </div>
        </section>
    );
}