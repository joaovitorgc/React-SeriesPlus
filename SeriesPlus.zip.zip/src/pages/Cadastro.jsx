import css from './Cadastro.module.css';
import Botao from "../components/Botao/Botao.jsx";
import { Link } from "react-router-dom";

export default function Cadastro() {
    return (
        <div className={css.paginaCadastro}>
            {/* O mesmo overlay escuro */}
            <div className={css.overlay}>

                <div className={css.caixaCadastro}>
                    <h1 className={css.titulo}>Criar conta</h1>

                    {/* Campo novo: Nome */}
                    <input
                        type="text"
                        placeholder="Nome completo"
                        className={css.input}
                    />

                    <input
                        type="email"
                        placeholder="Email"
                        className={css.input}
                    />

                    <input
                        type="password"
                        placeholder="Criar senha"
                        className={css.input}
                    />

                    <div className={css.areaBotao}>
                        <Botao texto="Cadastrar" estilo="padrao" />
                    </div>

                    <div className={css.jaTemConta}>
                        <span>Já tem uma conta? </span>
                        <Link to="/Login" className={css.linkBranco} >Entrar Agora</Link>
                    </div>
                </div>

            </div>
        </div>
    );
}