import css from './Catalogo.module.css';

import Controles from "../components/Controles/Controles.jsx";
import Card from "../components/Card/Card.jsx";



export default function Catalogo() {

    const todasAsSeries = [
        { id: 1, titulo: "Breaking Bad", imagem: "/brba.jpg" },
        { id: 2, titulo: "Cobra Kai", imagem: "/cobrakai.jpg" },
        { id: 3, titulo: "Stranger Things", imagem: "/std.jpg" },
        { id: 4, titulo: "The Walking Dead", imagem: "/twd.webp" },
        { id: 5, titulo: "Dexter", imagem: "/dex.jpg" },
        { id: 6, titulo: "Rick and Morty", imagem: "/ric.jpg" }
    ];

    return (
        <div className={css.paginaCatalogo}>

            <Controles />

            <main className={css.conteudo}>
                <h1 className={css.tituloCatalogo}>Séries Populares</h1>


                <div className={css.grade}>
                    {todasAsSeries.map((serie) => (
                        <div key={serie.id} className={css.itemGrade}>
                            <Card imagem={serie.imagem} titulo={serie.titulo} />
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
}