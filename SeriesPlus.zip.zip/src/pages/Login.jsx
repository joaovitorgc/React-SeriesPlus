import css from './Login.module.css';
import Botao from "../components/Botao/Botao.jsx";
import { Link } from "react-router-dom";

export default function Login() {
    return (
        <div className={css.paginaLogin}>
            <div className={css.overlay}>

                <div className={css.caixaLogin}>
                    <h1 className={css.titulo}>Entrar</h1>

                    <input
                        type="email"
                        placeholder="Email ou número de telefone"
                        className={css.input}
                    />

                    <input
                        type="password"
                        placeholder="Senha"
                        className={css.input}
                    />

                    <div className={css.areaBotao}>
                        <Botao texto="Entrar" estilo="padrao" />
                    </div>

                    <div className={css.novoAqui}>
                        <span>Novo por aqui? </span>
                        <Link className={css.linkRed} to="/Cadastro">Cadastre-se agora</Link>
                    </div>
                </div>

            </div>
        </div>
    );
}