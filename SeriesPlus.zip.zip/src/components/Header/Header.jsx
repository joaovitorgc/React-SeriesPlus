import { useState } from "react";
import css from "./Header.module.css";
import { Link } from "react-router-dom";

export default function Header({ titulo = "SERIESPLUS" }) {
    const [menuAberto, setMenuAberto] = useState(false);

    const toggleMenu = () => {
        setMenuAberto(!menuAberto);
    };

    return (
        <header className={css.fundoHeader}>
            <div className="container">
                <div className="row">
                    <div className="col-md-12 d-flex align-items-center justify-content-between">

                        <h1 className={css.titulo}>{titulo}</h1>

                        <button className={css.botaoMenu} onClick={toggleMenu} aria-label="Abrir menu">
                            ☰
                        </button>

                        <nav className={`${css.nav} ${menuAberto ? css.navAberta : ""}`}>
                            <a href="#">Mais Vistos</a>

                            <Link to="/Catalogo">Catálogo</Link>
                            <Link to="/Cadastro">Cadastre-se</Link>
                            <Link className={css.botaoLogin} to="/Login">Login</Link>
                        </nav>

                    </div>
                </div>
            </div>
        </header>
    );
}