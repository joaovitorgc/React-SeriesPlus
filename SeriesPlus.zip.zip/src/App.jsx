import './App.module.css';
import Home from "./pages/Home.jsx";
import {BrowserRouter, Routes, Route} from "react-router-dom";
import Header from "./components/Header/Header.jsx";
import Rodape from "./components/Rodape/Rodape.jsx";
import Login from "./pages/Login.jsx";
import Cadastro from "./pages/Cadastro.jsx";
import Catalogo from "./pages/Catalogo.jsx";

export default function App() {
    return (
        <BrowserRouter>

            <Header />
            <Routes>
                <Route path="/" element={ <Home /> } />
                <Route path="/login" element={ <Login /> } />
                <Route path="/cadastro" element={ <Cadastro /> } />
                <Route path="/catalogo" element={ <Catalogo /> } />
            </Routes>
            <Rodape />

        </BrowserRouter>
    )
}
